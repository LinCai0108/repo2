
library(devtools)
plot_cp()

# to load a source package: use load_all
load_all("../hw2")
plot_cp()

document("../hw2")



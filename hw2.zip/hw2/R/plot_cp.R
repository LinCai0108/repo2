
#' Plot mCPR data and estimates
#'
#' @param dat tibble which contains mCPR observations. Columns: iso, year, cp
#' @param est tibble which contains mCPR estimates. Columns: “Country or area”, iso, Year, Median, U95,
#' L95
#' @param iso_code country iso code
#' @param CI confidence intervals to be plotted. Options can be: 80, 95, or NA (no CI plotted)
#'
#' @return ggplot object with data and estimates
#'
#' @examples plot_cp(dat, est, iso_code, CI = 95)
#'
#' @export
plot_cp <- function(dat, est, iso_code, CI = 95) {
  est01 <- est %>%
    filter(iso==iso_code,!is.na(Year), !is.na(Median))
  dat01 <- dat %>%
    filter(iso==iso_code,!is.na(Year), !is.na(cp))

  plot <- ggplot() +
    geom_line(data = est01, aes(x = Year, y = Median)) +
    geom_point(data = dat01, aes(x = Year, y = cp)) +
    labs(x = "Time", y = "Modern use (%)",
         title = est01$`Country or area`[1])

  if (!is.na(CI) && CI == 80) {
    plot <- plot + geom_smooth(data = est01, stat = "identity",
                               aes(x = Year, y = Median, ymin = L80, ymax = U80))
  } else if (!is.na(CI) && CI == 95) {
    plot <- plot + geom_smooth(data = est01, stat = "identity",
                               aes(x = Year, y = Median, ymin = L95, ymax = U95))
  }
  else if (is.na(CI)) {
    plot <- plot
  }
  print(plot)
}

